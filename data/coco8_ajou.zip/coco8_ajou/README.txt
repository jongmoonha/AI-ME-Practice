coco8_ajou — eight labelled COCO 2017 images in YOLO format for the AI-ME practice notebooks (Ajou University).
Seven images and their labels are the Ultralytics coco8 sample; the validation image 000000000036 was replaced
by 000000000599 from the Ultralytics coco128 sample. Images: COCO (https://cocodataset.org), Flickr terms of use;
annotations: CC BY 4.0. Layout: images/{train,val}, labels/{train,val}, one .txt per image, lines "class cx cy w h".
